Thoughts for Gary - Version 0.8

Created by Ben Burum under Eclipse Public License - v1.0


Program Description:
Creates a window with a random picture of Gary Busey and a random quote from Friedriche Nietzche.  I think the appeal is obvious.

The button at the bottom will reload the page with a new image and quote.


If you want you can add more pictures to the Images folder, or more quotes to the "quotes.txt" file, and they will be added into the rotation.  Just make sure each quote is on its own line in the file, and that every file in the Images folder is an image of about the right size (no more than 600px or so in height).

Enjoy!